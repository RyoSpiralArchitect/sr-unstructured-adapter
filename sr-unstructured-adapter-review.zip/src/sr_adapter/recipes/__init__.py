# SPDX-License-Identifier: AGPL-3.0-or-later
"""Bundled recipes for the adapter pipeline."""

