# SPDX-License-Identifier: AGPL-3.0-or-later
"""Command line interface for the adapter pipeline."""

from __future__ import annotations

import argparse
import inspect
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
import sys

from .pipeline import batch_convert
from .writer import write_jsonl
from .drivers import DriverManager
from .normalizer import LLMNormalizer
from .recipe import load_recipe
from .runtime import RuntimeSnapshot, get_native_runtime, runtime_status_json
from .telemetry import TelemetryExporter

_BATCH_CONVERT_PARAMS = set(inspect.signature(batch_convert).parameters)


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert unstructured files into Blocks")
    subparsers = parser.add_subparsers(dest="command", required=True)

    convert_parser = subparsers.add_parser("convert", help="Convert files to JSONL")
    convert_parser.add_argument("paths", nargs="+", help="Files or directories to convert")
    convert_parser.add_argument("--recipe", default="default", help="Recipe to apply")
    convert_parser.add_argument("--out", required=True, help="Destination JSONL file")
    convert_parser.add_argument(
        "--no-llm",
        action="store_true",
        help="Disable low confidence LLM escalation",
    )
    convert_parser.add_argument(
        "--profile",
        default="balanced",
        help="Processing profile to orchestrate runtime + LLM policies",
    )
    convert_parser.add_argument(
        "--concurrency",
        type=int,
        default=0,
        help="Number of worker slots when using a distributed backend",
    )
    convert_parser.add_argument(
        "--backend",
        default=None,
        help="Distributed backend to use (auto, sync, threadpool, asyncio, dask, ray)",
    )
    convert_parser.add_argument(
        "--dask-scheduler",
        default=None,
        help="Override the Dask scheduler when using the dask backend",
    )
    convert_parser.add_argument(
        "--ray-address",
        default=None,
        help="Ray cluster address when using the ray backend",
    )

    llm_parser = subparsers.add_parser("llm", help="LLM driver utilities")
    llm_subparsers = llm_parser.add_subparsers(dest="llm_command", required=True)

    list_parser = llm_subparsers.add_parser("list-tenants", help="List configured tenants")
    list_parser.add_argument(
        "--quiet",
        action="store_true",
        help="Return success without printing when no tenants are configured",
    )

    run_parser = llm_subparsers.add_parser("run", help="Run a prompt against a tenant driver")
    run_parser.add_argument("--recipe", default="default", help="Recipe providing the LLM config")
    run_parser.add_argument(
        "--tenant",
        help="Tenant to use (defaults to recipe tenant or SR_ADAPTER_TENANT)",
    )
    run_parser.add_argument("--prompt", help="Prompt text (overrides stdin)")
    run_parser.add_argument(
        "--prompt-file",
        type=Path,
        help="Read prompt text from the given file (overrides stdin)",
    )
    run_parser.add_argument(
        "--metadata",
        help="Optional JSON object passed through to the driver as metadata",
    )
    run_parser.add_argument(
        "--metadata-file",
        type=Path,
        help="Read JSON metadata from a file (mutually exclusive with --metadata)",
    )

    replay_parser = llm_subparsers.add_parser(
        "replay",
        help="Replay prompts from a JSONL dataset against a tenant driver",
    )
    replay_parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="Path to a JSONL file containing prompts (fields: text/prompt, metadata)",
    )
    replay_parser.add_argument(
        "--output",
        type=Path,
        help="Optional JSONL destination for normalized responses",
    )
    replay_parser.add_argument("--recipe", default="default", help="Recipe providing the LLM config")
    replay_parser.add_argument(
        "--tenant",
        help="Tenant to use (defaults to recipe tenant or SR_ADAPTER_TENANT)",
    )
    replay_parser.add_argument(
        "--limit",
        type=int,
        help="Process at most this many successful prompts from the dataset",
    )
    replay_parser.add_argument(
        "--skip-errors",
        action="store_true",
        help="Continue replay when a record is invalid or the driver call fails",
    )

    kernel_parser = subparsers.add_parser("kernels", help="Native kernel utilities")
    kernel_subparsers = kernel_parser.add_subparsers(dest="kernel_command", required=True)

    status_parser = kernel_subparsers.add_parser("status", help="Show runtime telemetry")
    status_parser.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of a summary",
    )

    warm_parser = kernel_subparsers.add_parser("warm", help="Compile and warm kernels")
    warm_parser.add_argument(
        "--json",
        action="store_true",
        help="Emit runtime summary as JSON",
    )

    export_parser = kernel_subparsers.add_parser(
        "export",
        help="Export runtime telemetry for Prometheus/Sentry",
    )
    export_parser.add_argument(
        "--format",
        choices=("json", "prometheus"),
        default="json",
        help="Output format for stdout",
    )
    export_parser.add_argument(
        "--label",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Additional labels attached to Prometheus metrics",
    )
    export_parser.add_argument(
        "--sentry",
        action="store_true",
        help="Send the snapshot to Sentry after exporting",
    )

    return parser.parse_args(argv)


def _expand_paths(paths: list[str]) -> list[Path]:
    expanded: list[Path] = []
    for entry in paths:
        path = Path(entry).expanduser()
        if path.is_dir():
            expanded.extend(sorted(path.rglob("*")))
        else:
            expanded.append(path)
    return [path for path in expanded if path.is_file()]


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    if args.command == "convert":
        files = _expand_paths(args.paths)
        kwargs = {
            "recipe": args.recipe,
            "llm_ok": not args.no_llm,
        }
        if "profile" in _BATCH_CONVERT_PARAMS:
            kwargs["profile"] = args.profile
        if "concurrency" in _BATCH_CONVERT_PARAMS:
            kwargs["concurrency"] = args.concurrency
        if "backend" in _BATCH_CONVERT_PARAMS:
            kwargs["backend"] = args.backend
        if "dask_scheduler" in _BATCH_CONVERT_PARAMS:
            kwargs["dask_scheduler"] = args.dask_scheduler
        if "ray_address" in _BATCH_CONVERT_PARAMS:
            kwargs["ray_address"] = args.ray_address
        documents = batch_convert(files, **kwargs)
        write_jsonl(documents, args.out)
        return 0
    if args.command == "llm":
        return _handle_llm(args)
    if args.command == "kernels":
        return _handle_kernels(args)
    raise ValueError(f"Unhandled command: {args.command}")


def _handle_llm(args: argparse.Namespace) -> int:
    manager = DriverManager()
    if args.llm_command == "list-tenants":
        tenants = manager.tenant_manager.list_tenants()
        if tenants:
            for tenant in tenants:
                print(tenant)
        elif not args.quiet:
            print("No tenants configured", file=sys.stderr)
        return 0
    if args.llm_command == "run":
        try:
            prompt = _resolve_prompt(args.prompt, args.prompt_file)
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            return 2
        recipe = load_recipe(args.recipe)
        llm_config = dict(recipe.llm or {})
        if not llm_config.get("enable"):
            print(f"Recipe '{recipe.name}' does not enable LLM escalation", file=sys.stderr)
            return 3
        tenant = args.tenant or llm_config.get("tenant") or manager.tenant_manager.get_default_tenant()
        try:
            metadata = _resolve_metadata(args.metadata, args.metadata_file)
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            return 4
        driver = manager.get_driver(str(tenant), llm_config)
        try:
            raw = driver.generate(prompt, metadata=metadata)
        except Exception as exc:  # pragma: no cover - runtime failure path
            print(
                f"LLM driver '{driver.name}' failed for tenant '{tenant}': {exc}",
                file=sys.stderr,
            )
            return 10
        normalizer = LLMNormalizer()
        normalized = normalizer.normalize(driver.name, raw, prompt=prompt)
        json.dump(asdict(normalized), sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
        return 0
    if args.llm_command == "replay":
        dataset = args.input.expanduser()
        if not dataset.exists():
            print(f"Dataset '{dataset}' does not exist", file=sys.stderr)
            return 5
        if not dataset.is_file():
            print(f"Dataset '{dataset}' is not a file", file=sys.stderr)
            return 6
        recipe = load_recipe(args.recipe)
        llm_config = dict(recipe.llm or {})
        if not llm_config.get("enable"):
            print(f"Recipe '{recipe.name}' does not enable LLM escalation", file=sys.stderr)
            return 3
        tenant = args.tenant or llm_config.get("tenant") or manager.tenant_manager.get_default_tenant()
        driver = manager.get_driver(str(tenant), llm_config)
        normalizer = LLMNormalizer()
        output_handle = None
        if args.output:
            output_path = args.output.expanduser()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_handle = output_path.open("w", encoding="utf-8")
        stats = ReplayStats()
        try:
            with dataset.open("r", encoding="utf-8") as input_handle:
                for line_number, line in enumerate(input_handle, 1):
                    if args.limit is not None and stats.processed >= args.limit:
                        stats.limit_reached = True
                        break
                    stripped = line.strip()
                    if not stripped:
                        continue
                    stats.attempted += 1
                    try:
                        record = json.loads(stripped)
                    except json.JSONDecodeError as exc:
                        message = f"Invalid JSON payload on line {line_number}: {exc}"
                        if args.skip_errors:
                            stats.errors.append(message)
                            continue
                        print(message, file=sys.stderr)
                        return 7
                    prompt = _extract_prompt(record)
                    if not prompt:
                        message = (
                            f"Record on line {line_number} is missing a prompt/text field"
                        )
                        if args.skip_errors:
                            stats.errors.append(message)
                            continue
                        print(message, file=sys.stderr)
                        return 8
                    metadata = record.get("metadata")
                    try:
                        raw = driver.generate(prompt, metadata=metadata)
                    except Exception as exc:  # pragma: no cover - runtime failure path
                        message = f"LLM driver '{driver.name}' failed on line {line_number}: {exc}"
                        if args.skip_errors:
                            stats.errors.append(message)
                            continue
                        print(message, file=sys.stderr)
                        return 10
                    normalized = normalizer.normalize(driver.name, raw, prompt=prompt)
                    payload = {
                        "record": record,
                        "response": asdict(normalized),
                        "tenant": tenant,
                        "driver": driver.name,
                    }
                    target = output_handle or sys.stdout
                    json.dump(payload, target, ensure_ascii=False)
                    target.write("\n")
                    stats.processed += 1
        finally:
            if output_handle:
                output_handle.close()
        if stats.processed == 0:
            print("No prompts were processed from the dataset", file=sys.stderr)
            return 9
        if args.skip_errors or args.limit is not None:
            _report_replay_summary(stats, limit=args.limit)
        if stats.errors:
            return 10
        return 0
    raise ValueError(f"Unhandled llm command: {args.llm_command}")

def _handle_kernels(args: argparse.Namespace) -> int:
    runtime = get_native_runtime()
    if args.kernel_command == "status":
        return _emit_kernel_status(runtime, as_json=args.json)
    if args.kernel_command == "warm":
        snapshot: RuntimeSnapshot
        if runtime is None:
            runtime = get_native_runtime()
        if runtime is None:
            snapshot = RuntimeSnapshot(text_enabled=False, layout_enabled=False)
        else:
            snapshot = runtime.warm()
        return _emit_kernel_snapshot(snapshot, as_json=args.json)
    if args.kernel_command == "export":
        exporter = TelemetryExporter()
        try:
            labels = _parse_labels(args.label)
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            return 11
        try:
            if args.format == "prometheus":
                output = exporter.render_prometheus(extra_labels=labels)
            else:
                output = exporter.snapshot_json()
        except RuntimeError as exc:
            print(f"Failed to export telemetry: {exc}", file=sys.stderr)
            return 12
        if output := output.strip():
            print(output)
        if args.sentry:
            try:
                exporter.push_sentry()
            except RuntimeError as exc:
                print(f"Failed to push telemetry to Sentry: {exc}", file=sys.stderr)
                return 13
        return 0
    raise ValueError(f"Unhandled kernel sub-command: {args.kernel_command}")


def _emit_kernel_status(runtime: object | None, *, as_json: bool) -> int:
    if as_json:
        print(runtime_status_json())
        return 0
    if runtime is None:
        snapshot = RuntimeSnapshot(text_enabled=False, layout_enabled=False)
    elif isinstance(runtime, RuntimeSnapshot):
        snapshot = runtime
    else:
        snapshot = runtime.snapshot()  # type: ignore[call-arg]
    _print_kernel_snapshot(snapshot)
    return 0


def _emit_kernel_snapshot(snapshot: RuntimeSnapshot, *, as_json: bool) -> int:
    if as_json:
        print(json.dumps(snapshot.to_dict(), ensure_ascii=False, indent=2))
        return 0
    _print_kernel_snapshot(snapshot)
    return 0


def _print_kernel_snapshot(snapshot: RuntimeSnapshot) -> None:
    from .runtime import KernelStats  # local import to avoid cycle at module import

    def _format_line(title: str, enabled: bool, stats: KernelStats) -> str:
        status = "enabled" if enabled else "disabled"
        summary = (
            f"calls={stats.calls} total_ms={stats.total_ms:.2f} "
            f"avg_ms={stats.avg_ms:.2f} units={stats.total_units}"
        )
        if stats.failures:
            summary += f" failures={stats.failures}"
        return f"{title}: {status} ({summary})"

    print(_format_line("Text kernel", snapshot.text_enabled, snapshot.text_stats))
    print(_format_line("Layout kernel", snapshot.layout_enabled, snapshot.layout_stats))


def _parse_labels(entries: list[str]) -> dict[str, str]:
    labels: dict[str, str] = {}
    for entry in entries:
        if "=" not in entry:
            raise ValueError(f"Invalid label '{entry}'. Use key=value format.")
        key, value = entry.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            raise ValueError("Label keys must be non-empty")
        labels[key] = value
    return labels


def _resolve_prompt(prompt: str | None, prompt_file: Path | None) -> str:
    if prompt and prompt_file:
        raise ValueError("Provide either --prompt or --prompt-file, not both")
    if prompt:
        text = prompt
    elif prompt_file:
        text = prompt_file.expanduser().read_text(encoding="utf-8")
    else:
        text = sys.stdin.read()
    text = text.strip("\n")
    if not text:
        raise ValueError("Prompt text is empty")
    return text


def _resolve_metadata(metadata: str | None, metadata_file: Path | None) -> dict | None:
    if metadata and metadata_file:
        raise ValueError("Provide either --metadata or --metadata-file, not both")
    if metadata_file:
        path = metadata_file.expanduser()
        try:
            contents = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ValueError(f"Failed to read metadata file '{path}': {exc}") from exc
        try:
            return json.loads(contents) if contents.strip() else None
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid metadata JSON in file '{path}': {exc}") from exc
    if metadata:
        try:
            return json.loads(metadata)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid metadata JSON: {exc}") from exc
    return None


def _extract_prompt(record: dict | None) -> str | None:
    if not isinstance(record, dict):
        return None
    prompt = (
        record.get("prompt")
        or record.get("text")
        or record.get("input")
        or record.get("content")
    )
    if isinstance(prompt, str) and prompt.strip():
        return prompt
    return None


@dataclass
class ReplayStats:
    processed: int = 0
    attempted: int = 0
    errors: list[str] = field(default_factory=list)
    limit_reached: bool = False


def _report_replay_summary(stats: ReplayStats, *, limit: int | None, error_limit: int = 5) -> None:
    attempted_message = (
        f"{stats.processed} prompt(s) processed out of {stats.attempted} record(s)"
        if stats.attempted
        else f"{stats.processed} prompt(s) processed"
    )
    print(attempted_message, file=sys.stderr)
    if limit is not None and stats.limit_reached:
        print(f"Stopped after reaching limit of {limit} successful prompt(s)", file=sys.stderr)
    if stats.errors:
        print(f"{len(stats.errors)} record(s) failed:", file=sys.stderr)
        for message in stats.errors[:error_limit]:
            print(f"  - {message}", file=sys.stderr)
        remaining = len(stats.errors) - error_limit
        if remaining > 0:
            print(f"  ... {remaining} more", file=sys.stderr)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
