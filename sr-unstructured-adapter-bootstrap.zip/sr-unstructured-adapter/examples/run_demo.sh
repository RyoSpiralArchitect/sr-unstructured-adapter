#!/usr/bin/env bash
python -m sr_adapter.adapter examples/sample.txt
